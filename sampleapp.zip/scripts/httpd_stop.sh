#!/bin/bash

# Stop Apache service
echo "Stopping Apache service..."
sudo systemctl stop apache2

# Confirm Apache has stopped
echo "Apache service status:"
sudo systemctl status apache2 --no-pager

