#!/bin/bash

# Update the package index
echo "Updating package index..."
sudo apt update -y

# Install Apache HTTP server
echo "Installing Apache HTTP server..."
sudo apt install -y apache2

# Enable Apache to start on boot
echo "Enabling Apache to start on boot..."
sudo systemctl enable apache2

# Start Apache service
echo "Starting Apache service..."
sudo systemctl start apache2

# Confirm Apache is running
echo "Checking Apache status..."
sudo systemctl status apache2 --no-pager

