#!/bin/bash

# Start Apache service
echo "Starting Apache service..."
sudo systemctl start apache2

# Confirm Apache is running
echo "Apache service status:"
sudo systemctl status apache2 --no-pager

